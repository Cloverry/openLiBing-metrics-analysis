---
name: openlibing-nightly-rca
description: 对 openLiBing 工程运营看板的不达标指标做自动化取证与 AI 根因分析。脚本化采集（夜间统计双维度点灯→待分析流水线→执行历史双轨道圈定→失败任务两路分流→任务日志/测试用例日志取证→buildflow 子任务下钻→GitHub 平台运行取证（GitHub Actions API：jobs 元数据分流、失败 job 逐个精取或整包 zip、测试 job 测试结果解析定位到用例/模型）→证据合并），最后由 AI agent 按 profile 配置输出表格化根因报告，精确到「哪条流水线、哪个任务、哪个用例、什么错、什么原因」。支持双维度分析：版本可用度与编译成功率（Build* 子任务口径，buildflow 任务自动下钻失败子任务取真实编译报错；github 平台流水线不计算编译成功率）。增量采集缓存复用：已取证的运行不重抓（复用前状态校准，重试/重跑导致状态变更的自动重抓）。当用户要求"根因分析""分析不达标/红灯指标""nightly 失败原因""帮我分析 10.21-10.27""对 MindStudio 做分析"等时调用。支持指定日期区间（默认近 7 天不含当天）与一个或多个产品（默认全部）。
---

# openLiBing 不达标指标根因分析（脚本化采集 + AI 分析）

流水线：**第 1~6 步确定性脚本采集**（产物全部留档 `out/`，只增不删、长期归档），**第 7 步由执行本 skill 的 AI agent** 按 `agent/agent_task.md` + `agent/analysis_profile.json` 完成根因分析并输出报告。采集与分析解耦：改分析配置不动数据，可对同一份证据反复重分析。

## 一、前置条件

1. **调试 Chrome 已登录 openLiBing**（登录态 cookie 保留在用户数据目录）：
   ```powershell
   Start-Process 'C:\Program Files\Google\Chrome\Application\chrome.exe' `
     -ArgumentList '--remote-debugging-port=9222', '--user-data-dir=C:\Users\<用户名>\AppData\Local\Google\Chrome\User Data', 'https://www.openlibing.com/apps/eCDashboard'
   ```
   已有实例在跑时需先退出 Chrome 再带参启动。所有网关接口同源 fetch（自动带 cookie），鉴权只需回填 `Csrf-Token-Open-Li-Bing` = cookie `csrf-token-open-li-bing`。
2. **Node.js >= 22**（需内置 WebSocket，驱动 CDP）与 **Python >= 3.8**（标准库即可）。
3. 无需向任何人索要接口：全部网关路径已固化在 `tpl/` 模板中。
4. **待分析清单含 github 平台流水线时**（如 vllm-ascend）：`config.github.token` 需配置 GitHub PAT（Actions 日志读权限），否则第 5c 步报错退出；纯 openlibing 平台流水线无需该项。

## 二、快速开始

```powershell
# 1) 编辑 config.json 设定区间与产品（或用命令行参数）
# 2) 一键采集（第 1~6 步）——终端只显示步骤头/错误关键行，完整输出落 out/run_pipeline.log
#    每步失败自动重试 1 次（--retries 可调），无人值守防中断
python run_pipeline.py
# 或临时覆盖参数
python run_pipeline.py --start 2026-10-21 --end 2026-10-27 --products MindStudio,Ascend-CANN
# 断点续跑 / 单步调试
python run_pipeline.py --from step4
python run_pipeline.py --only step2
# 看实时进度（另一个终端）
Get-Content out\run_pipeline.log -Tail 50 -Wait

# 3) 第 7 步：agent 按 agent/agent_task.md 分析，入口必跑索引摘要（禁止整读大 JSON）
python out/_analysis_summary.py
```

**无人值守防中断（一把过）**：采集链路 stdout 摘要制（各步骤全部输出落 `out/run_pipeline.log`，终端仅透传步骤头与 `!!` 错误行，不会触发「输出过长请输入继续」）；步骤失败自动重试（默认 1 次），重试仍失败才中止并打印日志尾部与续跑命令；agent 分析阶段遵守 `agent/agent_task.md` 的「无人值守输出纪律」（摘要脚本入口、行号窗口读、单命令回显 ≤100 行、不暂停提问）。

### 增量复用（默认开启，`config.cache.enabled`）

- **复用范围**：上一次已取证的运行（构建列表 T4 分流、失败用例 T6 结果、用例日志解析、整 job 全量日志导出与错误行扫描、buildflow 子任务下钻与失败子任务日志、GitHub 运行 jobs 元数据与 job 日志）在本次分析中直接复用，**仅补抓上次拉取之后的新运行**；第 1/2 步（夜间统计、N2 看板执行记录）始终拉最新
- **状态校准（复用前提）**：任务可能发生重试/重跑导致状态变更——openlibing 平台运行在第 2 步比对 N2 `status`/结束时间，github 平台运行在第 5c 步比对 GitHub 状态快照（`status/conclusion/updated_at/run_attempt`，GET runs/{rid}）；与缓存记录不一致（或旧缓存无快照）的条目自动失效重抓，不依赖 `--fresh`
- **剔除规则**：运行日期在本次分析区间 `[start, end]` 之外的缓存条目自动剔除，不进入本次分析与缓存
- **失效重抓**：上次采集 T4 出错（任务图谱未知）、证据有缺口、日志文件缺失或用例日志下载失败的条目视为失效，本次自动重新抓取；导出超时但分页兜底成功的过程性错误不阻塞复用
- **缓存文件**：`out/cache/collection.json`（按 运行 rid 索引，step5 末尾自动写入；日志/用例文件本体在 `out/job_logs/`、`out/case_logs/`，文件名序号自动续号不覆盖）
- **首次接入已有数据**：`python bootstrap_cache.py` 可从 `out/` 现有产物直接建缓存，无需重新抓取
- **强制全量重抓**：`python run_pipeline.py --fresh`（跳过复用，重抓结果仍写回缓存）
- 分析（第 7 步）不受缓存影响：合并产物 `analysis_input.json` 结构不变，agent 无需感知

## 三、配置（config.json）

| 字段 | 说明 |
|---|---|
| `date_range.start/end` | 分析区间，yyyy-mm-dd；**留空自动取近 7 天不含当天**（start=今天-7，end=今天-1）。夜间统计仅统计区间内**工作日**（服务端口径，无需自行计算） |
| `products` | 产品范围；`[]` = 全部产品（产品清单与 projectId 由看板自动发现）；`["MindStudio"]` 或多产品 = 只分析指定产品 |
| `project_id_map` | 可选兜底：产品 → projectId。优先从一级汇总接口自动发现（记录自带 projectId） |
| `chrome` | 调试端口（默认 9222）、标签页 URL 子串、单次执行超时、请求间隔、分批大小 |
| `collect` | 各接口分页参数（t1/nightly_detail/n2/t5/t6）、用例日志下载并发、单用例最大错误行数、大文件阈值（默认 4MB，超出只扫尾部） |
| `cache` | 增量采集缓存（`enabled` 默认 true，`path` 默认 `cache/collection.json`）；复用前状态校准（N2 状态/结束时间、github 状态快照），状态变更自动重抓；`--fresh` 可临时跳过复用 |
| `github` | 第 5c 步 GitHub Actions 取证：`token`（PAT，必需，仅 github 流水线出现在待分析清单时才需要）、`api_base`（默认 `https://api.github.com`）、`repos`（产品 → `owner/repo` 兜底映射；优先取 N2 记录内 repoUrl） |
| `agent` | 第 7 步 agent 使用的任务书与分析配置路径 |

执行前应与用户复述确认：**日期区间 + 产品范围**（两者均有缺省值）。

## 四、统计与筛选规则（官方口径，不自行计算，双维度）

**版本可用度（VA）**

- **夜间统计只统计工作日**：直接调官方 `ops-nightly-detail` 接口，返回的 `versionAvail` 已按工作日算好（0-1 小数），**转百分比展示即可，禁止用日历天数自行重算**
- **组件级版本可用度**：直取 T1 接口返回的 `nightlyVersionAvailabilityRate`，不自行计算；点灯：`>=90%` 绿 / `[80%,90%)` 黄 / `<80%` 红
- **进入分析的条件**：该组件下 **`versionAvail != 1` 的流水线进入 VA 维度分析**（不按流水线级阈值二次筛选，也不按组件灯色拦截——绿灯组件若有未达标流水线同样分析，灯色仅作展示）
- **日可用口径（双指标）**：`availDays` 按服务端逐运行 `isVersionAvailable`（N2 `nightly-dashboard-detail`）判定——任务构建成功且测试用例通过率 100%（`casePassRate` 为空/-- 视为失败），当天任一次运行 `isVersionAvailable=true` 即当天可用；执行记录即 N2 逐运行明细（同运行多条评估记录保留结束时间最新一条）；N2 接口失败的流水线无执行记录，记 `_meta.dashFailed` 待办
- 口径内流水线由服务端决定（无需版本级/组件级筛选逻辑）；`versionAvail` 无数据的流水线不计入均值并记录待办

**编译成功率（BS）**

- **指标定义**：Nightly 流水线的成功编译能力；**组件级**直取 T1 的 `nightlyBuildSuccessRate`（项目级 = AVG(各流水线日成功率)，服务端算好）；**流水线级**直取 N1 的 `buildSuccess`（成功编译的构建次数/总编译次数：服务端优先 Nightly-Version-Pipeline 命名口径，无则 Nightly-Component-Pipeline 多条取平均；失败重试一次算流水线失败一次）；仅统计工作日
- **逐运行复算（仅异常时标注）**：报告对每条流水线做逐运行复算校验（Σ`buildPassCount`/Σ`buildCount`，N2 逐运行字段，`runHistory.bc`/`bpc`）：与服务端值一致时不写任何复算叙事、按真实构建失败定性；**不一致（差异超过 0.5 个百分点）时才标注统计口径异常**（如挂起运行按评估日重复计数）
- **点灯**：`=100%` 绿 / `[95%,100%)` 黄 / `<95%` 红
- **任务口径**：构建数据为子任务名以 `Build`（大小写不敏感）开头的任务；一条流水线一次执行出现多次构建失败在计算时算一条数据
- **进入分析的条件**：`buildSuccess` 非 null 且 `!= 1` 的流水线进入 BS 维度分析（与 VA 取**并集**圈定流水线，同一流水线可能同时命中两维）
- **构建全成功运行**：下钻时仍取非 1 的值；若流水线内部构建全成功（无 Build* 失败任务，记入 `bsCleanRuns`），不编根因，note 仅在逐运行复算（Σbpc/Σbc）与服务端 `buildSuccess` 不一致时标注口径异常；`buildSuccess` 返回 null 的流水线记待办不下钻
- github 平台流水线：`pipelineRunId` 即 GitHub Actions run id，执行记录来自 N2（同口径圈定）；任务/日志数据不在 openlibing-cicd 接口范围，由第 5c 步经 GitHub Actions API 取证；**不计算编译成功率**——服务端 `buildSuccess` 恒为 null（BS 维度无数据，仅 VA 维度分析），`runHistory` 的 bc/bpc（编译次数/编译成功次数）显式置 null 不采集不展示，报告构建记录弹窗中编译成功率两列不展示

## 五、采集步骤（step1~step6，一步一接口）

| 步骤 | 脚本 | 接口 | 判定/处理规则 | 产物 |
|---|---|---|---|---|
| 1 | `steps/step1_nightly.py` | T1 产品发现 + N1 夜间明细 | T1 自动发现产品清单（含 projectId 与**组件级官方 nightlyVersionAvailabilityRate / nightlyBuildSuccessRate**）→ 逐产品调 N1 拿官方口径流水线 → **组件级两指标直取 T1 字段，不自行计算** → 双指标点灯 → **双维度并集圈定**：`versionAvail != 1`（VA 维度）或 `buildSuccess` 非 null 且 `!= 1`（BS 维度）的流水线进入分析，每条带 `dims` 标注（不看组件灯色）；github 平台流水线一并圈定并透传 `platform` 标记（取证分流见第 5c 步） | `step1_products.json`、`step1_bad_pipelines.json` |
| 2 | `steps/step2_runs.py` | N2 看板明细（执行记录唯一来源） | **时间口径：运行按【结束时间】归属**——是否落入统计周期、归属哪一天、是否工作日均以 `pipelineRunEndtime` 判定（跨午夜运行归到结束日；进行中/无结束时间的运行不纳入本周期）→ **工作日筛查**（`lib/workdays.py`：timor.tech 法定节假日 API 自动识别调休补班，config `workday_overrides` 兜底，周一~五回退；**周末与法定假不分析，法定调休补班算工作日**）→ **N2 执行记录采集**（`nightly-dashboard-detail` 逐流水线按 `total` 分页拉全：`pipelineRunNumber/Id/Status/起止时间` + `isVersionAvailable`/`buildCount`/`buildPassCount`/`failedTaskType`/`casePassRate`，同运行多条评估记录按运行号去重保留结束时间最新一条；**不再调 T3 pipeline-run/list 在流水线上取执行记录**——待查运行直接以记录内 `pipelineRunId` 构造 openlibing `/apps/pipelineDetail` 链接下钻，第 3 步 T4 用同一 rid；N2 失败的流水线无执行记录，记 `_meta.dashFailed` 待办）→ **双轨道圈定（按 rid 全局去重，同一运行只取证一次）**：VA 轨道按日豁免——当天任一次运行 `isVersionAvailable=true` → 当天可用，跳过当天全部失败；当天无可用 → 当天 FAILED/CANCELED 入待查（track=va）；BS 轨道任务级语义——BS 命中的流水线即使当天已有成功运行，同日 FAILED/CANCELED 仍可能是 Build* 失败，补圈为 bs-only 待查（track=bs）；**CANCELED（人工取消/已停止）运行同样取证**；每流水线同时导出 runHistory 全量构建记录（含 bc/bpc/cpr/iva/ftt/url 字段，供报告弹窗 7 列展示；**github 平台流水线 bc/bpc 置 null**——不计算编译成功率，不采集不展示编译次数/编译成功次数）；**缓存状态校准**：复用前比对 N2 `status`/结束时间与缓存记录，重试/重跑导致状态变更的条目失效重抓；两指标值以第 1 步接口为准 | `step2_failed_runs.json`（含 `_meta` 工作日口径/VA 双指标规则/N2 失败清单、runHistory 与 track/dims 标注）、`step2_dash_raw.json` |
| 3 | `steps/step3_tasks.py` | T4 运行详情 | **github 平台运行直接跳过 T4**（openlibing-cicd 无该平台任务数据，全部转第 5c 步 GitHub 取证，不产生 T4 采集参数）；失败任务图谱：`data.stages[].jobs[].steps[]`，job.id=jobRunId、step.id=stepRunId、step/job 均带 `last_dispatch_id`；**剔除**状态 UNSELECTED/CANCELED/IGNORED/INIT、非 FAILED 与无失败步骤的任务；补采失败步骤 `errMsg`/`lastDispatchId`（导出接口主键）与 `inputs[]` 中 `key='jobId'` 的构建 jobId（buildJobId/jobIdParam，第 5b 步子任务下钻必填）；**两路分流**：任务名 test 开头（不分大小写）→ test 路线，否则 → log 路线；**BS 轨道过滤**（track=bs 的运行）：仅保留 Build*（大小写不敏感开头）失败任务；Build* 全成功的 bs-only 运行记入 `bsCleanRuns`（报告做逐运行复算校验） | `step3_params.json`（含 `bsCleanRuns`） |
| 4 | `steps/step4_testreport.py` | T6 测试结果 | `state:['failed']` 过滤失败用例（含断言消息与用例日志 OBS 直链）；用例日志并发下载后**全文件扫描**（带行号 `line`，不读尾部）提取 Level=ERROR/FAIL 行，行级无果再深挖 Test FAILED/Traceback 块；暴露 `localLog` 供 agent 回原文核对；**空测试结果任务标记 empty 待回退** | `step4_test_evidence.json`、`step4_case_errors.json`、`case_logs/` |
| 5 | `steps/step5_logs.py` | E 导出 + T5 分页兜底 | **主路径**：`exec-log/export` 创建导出任务 → 轮询 `export/detail` → `export/download-url` 拿 OBS 直链 → Python 流式下载**整 job 全量日志落盘**（150MB+ 不截断，含 job 内部真实执行日志）→ 全文件错误行扫描（`L<行号>:` 前缀）+ ≥5MB 生成摘录（头 100 + 错误行 + 尾 1500）；**降级**：导出失败/超时走原 T5 分页接口（400 页/24MB 上限必截断，标记 truncated，且分页只能拿到包装层轮询日志） | `job_logs/`（全量日志+manifest）、`step5_log_evidence.json` |
| 5b | `steps/step5b_subtasks.py` | F 子任务列表 + B1 子任务日志导出 + B2 分页兜底 | **buildflow 子任务下钻（仅 log 路线任务）**：逐任务调 flow 接口（`stepRunIds`=全部失败步骤）拉构建子任务列表 `builds[]`（`id/build_no/status/display_name`）——**空列表=普通流水线，直接跳过不产生额外请求**；失败子任务（status=FAILURE）逐个 `build-log/export` 创建导出任务（**jobId=第 3 步从 T4 失败步骤 `inputs[].key='jobId'` 提取的构建 jobId**，buildNo=flow `build_no`，stepRunId=父步骤 id）→ 轮询 `export/detail` → `export/download-url` OBS 直链 → Python 流式下载**子任务全量日志**落盘 `job_logs/NN_<流水线>_<构建号>_<任务>_<子任务>.log`；导出失败/超时降级 `build/log` 尾部窗口（标记 truncated）；证据挂 `step5_log_evidence.json` 对应任务 `subTasks[]`；缓存复用条件含失败子任务日志齐备 | `job_logs/`（子任务日志）、`step5_log_evidence.json`（subTasks 字段） |
| 5c | `steps/step5c_github.py` | GitHub Actions API（PAT 鉴权） | **github 平台运行取证（T4/T5/T6/E/F/B1 均不适用）**：`pipelineRunId` 即 GitHub run id，零转换。① `GET /repos/{repo}/actions/runs/{rid}/jobs` 拉全部 job 元数据（`conclusion/started_at/completed_at/steps[]`，>100 自动翻页）→ ② 决策树（目标 = 失败 job 优先，无失败则取消）：目标 ≤5 个逐 job 精取 `GET /repos/{repo}/actions/jobs/{job_id}/logs`（302→blob 纯文本）；>5 个取整包 `GET /repos/{repo}/actions/runs/{rid}/logs`（302→blob zip，一次含全部 job 主日志 + system.txt；实测 zip 域 ~110KB/s 远高于 per-job blob ~7KB/s）→ ③ zip 条目名匹配（实测规则：API job 名 `replace('/','_')`、去引号/换行/制表符即 zip 条目名，长 matrix 名两侧同在 ~95 字符处 `...` 截断）；zip 缺失目标 job 自动回退 per-job 端点 → ④ **取消 job 日志 GitHub 侧可能未留存**（blob 404 BlobNotFound）→ 记 `404_not_retained`（确定缺失非错误），根因以 jobs 元数据（conclusion/时长/失败步骤）定性并标注证据不完整 → ⑤ blob 分块下载（1MB/块、单块 60s 超时防慢速卡死、gzip 解压、512MB 上限、重试 3 次）→ ⑥ 错误行扫描与第 5 步同规格（`L<行号>:` 前缀，跳过 `##[group]` 脚本回显块）→ ⑦ **测试 job 测试结果解析**（job 名 single/multi/double-node 开头）：解析测试日志输出结构化 `testResults`（`failedModels` 逐模型失败 `Test failed for model`+最近 pytest FAILED/汇总、`aisbenchFailed` 失败用例 case+reason、`benchmarkFailed`、`failedTagTests` FAIL_TAG ✗、`pytestFailed`/`pytestSummaries`），剥离 ANSI 颜色码与时间戳、跳过 group/echo 回显，供报告定位到具体用例/模型 → ⑧ 断点续跑幂等（`_done.json` 带 `_v` 版本号，旧格式清目录重采；jobs.json/zip/单 job 日志存在即跳过对应环节）→ **缓存状态校准**：复用前 GET `/repos/{repo}/actions/runs/{rid}` 取状态快照（`status/conclusion/updated_at/run_attempt`）与缓存 `runStatus` 比对，重试/重跑导致变更（或旧缓存无快照）→ 清目录重取；校准接口失败复用上次证据下轮再校准；缓存与主流程同 (key, rid) 粒度，`ghComplete=true`（目标 job 全有日志或确定性 404）才算完整 | `github_logs/gh_<rid>/`（jobs.json、job 日志、_done.json）、`step5c_github_evidence.json` |
| 6 | `steps/step6_merge.py` | — | 装配 `组件概览（双指标双灯色）→ 流水线（dims/runs 带 track）→ 运行 → 任务(test/log，log 任务带 subTasks 子任务证据) → 用例 → 错误消息` 完整证据链 + `bsCleanRuns` + `logFileIndex` 全量日志索引 + coverage 子任务取证统计（buildFlowTasks/failedSubTasks/subtaskLogFiles/subtaskLogBytes）；**github 运行装配**：目标 job 证据行装配为 log 形态任务（`platform=github`、`githubJob` 步骤元数据、404 未留存任务带 `evidenceNote`），**测试 job（isTestJob）附 `testResults` 用例级测试结果定位**，运行级 `githubMeta`（mode/why/failedJobs/cancelledJobs/systemLogs/missing），coverage 新增 githubPipelines/githubRuns/githubJobs/githubLogFiles/githubLogBytes/github404/githubZipRuns/githubTestJobs/githubTestResultItems；证据引用一律 `文件名:行号` | `analysis_input.json` |

说明：第 4 步用 T6、第 5 步用 T5，是因为空测试回退依赖第 4 步结果；接口编号对应下文速查表。
第 2 步末尾按本次区间剔除缓存、标记可复用运行；第 3~5b 步对缓存命中的运行**不再调接口**（任务分流/用例取证/日志导出/子任务下钻直接取 `out/cache/collection.json`），第 5 步末尾把新抓取与复用结果一并写回缓存。
第 5b 步仅对 log 路线任务执行（test 路线已有用例级证据；空测试回退任务的整 job 日志已在第 5 步落盘）；缓存行 subTasks 已含失败子任务日志时跳过下钻。`--only step5` 会同时执行第 5 步与第 5b 步（前缀匹配）。
第 5c 步对 github 平台运行同理走缓存（缓存行 `github` 字段 + `ghComplete` 完整性标记，未完整的下次自动重抓），复用前先做状态校准（运行状态快照比对，变更即清目录重取），第 5c 步末尾把 github 证据一并写回缓存；断点续跑时已落盘的 jobs.json/zip/单 job 日志直接复用，只补缺失环节（`_done.json` 版本号不匹配则整目录重采）。

## 六、第 7 步：agent 根因分析（可变性入口）

执行本 skill 的 AI agent 完成采集后：

1. 读 `agent/agent_task.md`（任务书：分析流程、表格化报告模板、硬性规则、输出要求）
2. 读 `agent/analysis_profile.json`（**全部可变项**）：
   - `analysis.classification`：根因定性分类体系（可增删改）
   - `analysis.wording_rules`：报告措辞硬性规则（不出现外部平台/「需到 XX 平台查看」类说辞；「计算一致/复算一致」类描述一律不写，服务端值与逐运行复算仅在不一致时标注；用例通过率未达 100% 的不达标表格化为一条记录）
   - `analysis.dimensions`：双维度指标定义（版本可用度 va / 编译成功率 bs：数据来源、灯色阈值、任务口径）
   - `analysis.confidence_rules`：置信度标准
   - `analysis.deep_dive.subtask_drilldown`：buildflow 子任务下钻规则（失败子任务以 subTasks[].errorLines/logFile 为准，整 job 调度层记录仅作上下文）
   - `analysis.wrapper_codes`：封装错误码清单（不算结论）
   - `analysis.context_dimensions`：上下文分析维度
   - `analysis.extra_focus`：附加专项关注点（自由文本，agent 逐条执行）
   - `report`：语言、输出目录、文件名模板、**章节与表格列定义**（开源组件级概览表（全组件，含待分析为 0）/ 逐流水线根因表）、首页日期筛选（快捷区间 + 起止日期组件）、表格截断长度、格式（html/json）、html 样式与构建定位链接规则
3. 以 `out/analysis_input.json`（范围与索引）+ `out/job_logs/`（整 job 全量日志 + buildflow 子任务全量日志）、`out/case_logs/`（日志原文）为输入产出报告到 `out/report/`；**分析入口**：`python out/_analysis_summary.py`（全局索引）→ `--pipeline <子串>` / `--rn <构建号>` 逐级下钻，**禁止整读 analysis_input.json**（约 1MB/近 2 万行）；**深挖纪律**：凭 `errorLines` 行号 / `errorMessages[].line` 回全量日志定位错误上下文（buildflow 任务回失败子任务日志），根因必须落到具体报错原文，引用格式 `文件名:行号`；**排队类根因（Pending/queued）必须举证完整等待时间线**（申请开始→首查状态→轮询次数与间隔→放弃时间，逐点 `文件名:行号`，等待时长按起止时间差），禁止只写「资源调度失败」类笼统结论（`profile.deep_dive.pending_timeline`）

报告为**HTML 单文件**（单/多组件共用同一模板，内嵌 CSS、页面宽 `min(1560px,94vw)` 居中、双击即开），采用**总览页 + 二级页（按维度分页）**两级视图，全文统一使用「开源组件」术语：总览页只有一张表——开源组件级概览（官方 nightlyVersionAvailabilityRate / nightlyBuildSuccessRate 双列，渲染为百分比 + 6px 细进度条并按绿/黄/红分档；「待分析流水线数（版本可用度）/（编译成功率）」两列可点击分别进入该组件对应维度二级页；**全量开源组件一律列出，待分析数为 0 显示 0 不可点击**），表上方为**日期筛选工具条**（全部 / 昨天 / 最近 7 天 / 最近 30 天 四个快捷按钮 + 起止日期组件可随机选日；切换时按内嵌逐日矩阵、按工作日口径前端重算 VA/BS 并原地回写，不重新抓数），表容器固定高度 + 表头吸顶（行数增减不改变表格高度，超出内部滚动）；已取消「跨流水线共性」「结论与建议」两章（页面结构为固定展示版，不设流程性待办章节）；二级页每组件两页（`view-组件ID-va` / `view-组件ID-bs`，同一流水线两维都命中则两页都出现、根因行共用编号），页内含逐流水线根因表（根因编号/任务/用例/**错误信息（整格可点击弹证据详情：时间/来源文件/报错记录原文）**/定性/置信度/**执行记录（点击弹窗展示 任务名/构建号/执行时间，下方小字保留复现摘要）**/**构建定位（openlibing `/apps/pipelineDetail` 直达链接）**/建议；BS 页流水线标题仅在服务端值与逐运行复算不一致时附口径异常小字）；每条流水线标题旁「查看构建记录」链接弹窗 7 列展示 构建号（可点击跳转）/开始时间/结束时间/编译次数/编译成功次数/失败任务类型/构建状态 按开始时间降序。使用者无需改代码即可调整分析行为。

## 七、接口速查表（实测通过，2026/11/02）

同源调用，鉴权：请求头 `Csrf-Token-Open-Li-Bing`，值取 cookie `csrf-token-open-li-bing`。用例日志为 OBS 直链，无需鉴权直接下载。

| 编号 | 用途 | 路径 | 关键参数形态 |
|---|---|---|---|
| T1 | 产品清单发现（全部产品，含 projectId） | `POST /gateway/openlibing-ops/manage/ops-overview/main` | `{startDate, endDate, page, pageSize<=100}`（超 100 报「每页大小不能超过100」）；每条产品记录自带 `nightlyVersionAvailabilityRate` / `nightlyBuildSuccessRate`（组件级双指标） |
| N1 | 夜间统计明细（官方工作日口径） | `POST /gateway/openlibing-ops/manage/common/detail` | `{category:'ops-nightly-detail', projectId, startDate, endDate, page:1, pageSize:10}`；**projectId 必填**（缺失报「项目id不能为空」）；返回 `records[]` 含 `pipelineId/pipelineName/platform/versionAvail/buildSuccess`，`versionAvail` 为 0-1 小数 |
| N2 | 看板明细（执行记录唯一来源） | `POST /gateway/openlibing-ops/manage/common/detail` | `{category:'nightly-dashboard-detail', projectId, pipelineId, startDate, endDate, page:1, pageSize:100}`；返回 `records[]` 逐运行明细（`pipelineRunNumber/pipelineRunId/pipelineStatus/pipelineRunStarttime/pipelineRunEndtime` + `isVersionAvailable/buildCount/buildPassCount/failedTaskType/casePassRate/workflowRunUrl`），`data.total` 供翻页；第 2 步执行记录与双指标字段均取自此接口，不再调流水线侧 `pipeline-run/list` |
| T4 | 运行详情（失败任务图谱） | `GET /gateway/openlibing-cicd/project/pipeline/pipeline-run/detail?projectId=&pipelineId=&pipelineRunId=` | 三参数走 query，仅需 CSRF 头 |
| E | **整 job 全量日志导出**（页面「下载」按钮同款） | `POST /gateway/openlibing-cicd/project/pipeline/exec-log/export` → `GET /gateway/openlibing-framework/export/detail?id=<exportId>` 轮询 → `GET /gateway/openlibing-framework/export/download-url?id=<exportId>` | 创建：`{projectId, pipelineId, pipelineRunId, jobRunId, stepRunId, lastDispatchId, taskName}`（返回 `data` 为 exportId 字符串）；轮询：`data.message`「导出文件生成中」继续 /「导出成功」取直链；直链为 OBS，**浏览器外 Python 直接下载**（OBS 无 CORS 头，页面内 fetch 反而受限） |
| T5 | 任务日志（右侧日志，兜底用） | `POST /gateway/openlibing-cicd/project/pipeline/logs` | `{projectId, pipelineId, pipelineRunId, jobRunId, stepRunId, sort:'desc', limit:300, startOffset:0, endOffset:0}`；**400 页/24MB/5 分钟上限，长任务必截断；且只能拿到包装层轮询日志** |
| T6 | 测试结果/用例列表 | `POST /gateway/openlibing-cicd/project/pipeline/test-report` | `{projectId, pipelineId, pipelineRunId, stepRunIds, name:'', number:'', state:['failed'], pageNumber:1, pageSize:100}` |
| F | **buildflow 构建子任务列表**（页面流水线详情图「构建子任务」面板同款） | `GET /gateway/openlibing-cicd/project/pipeline/flow?projectId=&pipelineId=&pipelineRunId=&stepRunIds=` | query 四参数，`stepRunIds` 逗号连接全部失败步骤；返回 `data[]` 按 stepRunId 分组，`[].builds[]` 含 `id`（子任务构建实例 UUID）、`build_no`、`status`（FAILURE/SUCCESS…）、`display_name`、`build_duration/start_time/finish_time`；**普通流水线返回空 builds**（无子任务层，下钻安全跳过） |
| B1 | **子任务全量日志导出** | `POST /gateway/openlibing-cicd/project/pipeline/build-log/export` → 同 E 的 `export/detail` 轮询 + `export/download-url` OBS 直链 | 创建：`{projectId, jobId, buildNo, stepRunId, pipelineId, pipelineRunId, taskName}`；**jobId 必须是 T4 失败步骤 `inputs[].key='jobId'` 的构建 jobId**（flow 的 `builds[].id` 传参报 500「构建任务不属于该流水线运行实例」）；`buildNo` 取 flow `builds[].build_no`；返回 `data` 为 exportId，轮询/下载与 E 完全同模式 |
| B2 | 子任务日志分页（B1 失败时兜底） | `GET /gateway/openlibing-cicd/project/pipeline/build/log?projectId=&jobId=&buildNo=&stepRunId=&startOffset=0&endOffset=0&pipelineId=&pipelineRunId=&sort=DESC` | query 全量参数（缺 `buildNo` 报 4010102）；`sort=DESC` 取尾部窗口，响应 `data.log`（日志文本）+ `has_more/start_offset/end_offset` 滚动分页；只作兜底，标记 truncated |
| GH | **GitHub Actions 取证（第 5c 步，PAT 鉴权，不走 openlibing 网关）** | `GET {api_base}/repos/{owner}/{repo}/actions/runs/{rid}/jobs?per_page=100&page=N`、`GET {api_base}/repos/{owner}/{repo}/actions/runs/{rid}`（状态快照，缓存校准用）、`GET {api_base}/repos/{owner}/{repo}/actions/jobs/{job_id}/logs`、`GET {api_base}/repos/{owner}/{repo}/actions/runs/{rid}/logs` | 鉴权头 `Authorization: Bearer <config.github.token>`；jobs 响应 `{total_count, jobs[]}` 按 total 翻页（`conclusion/steps[]/started_at/completed_at`）；runs/{rid} 返回 `status/conclusion/updated_at/run_attempt`（状态校准快照）；两个 logs 端点均 302 → Azure blob 短时效签名直链（下载不带 token）；per-job 为纯文本，run 级为 zip（根级 `<seq>_<job 名>.txt` 主日志 + `<job 名>/system.txt` 系统日志）；repo 取 N2 记录 repoUrl（`github.com/{owner}/{repo}`），`config.github.repos.<产品>` 兜底 |

**T4 响应**：`data.stages[].jobs[]` → 失败任务含 `id`（jobRunId）与 `steps[].id`（stepRunId）；失败步骤 `steps[].inputs[]`（key/value 对）中 `key='jobId'` 的 value 为云构建（buildflow）任务的构建 jobId，第 5b 步子任务日志下钻必填（stepRunId 仍为父步骤 id）。
**T5 响应**：`data.log` 日志文本 + `has_more/end_offset` 滚动分页。
**T6 响应**：`data.list[]` 失败用例含 `name/description(断言消息)/beginTime/endTime/resultDownloadUrl(用例 HTML 日志)/envDownloadUrl(环境日志 zip)`。
**N1 注意**：`buildSuccess` 为流水线级编译成功率（服务端 Build* 子任务工作日口径，0-1 小数；实测存在返回 null 的时期/流水线）——返回 null 时该流水线 BS 无数据，记待办不阻塞 VA 分析。

**API 逆向方法**（新增接口时用）：openLiBing 为 Wujie 微前端，业务 JS（`/build/assets/index-*.js`）内含全部网关路径常量，静态 grep `/project/pipeline/` 或 `category` 即可，无需 DevTools 抓包。

## 八、陷阱与注意事项

1. **T5 参数形态**：`stepRunId` 是单数字符串，传数组报 `4010103 Step Run ID cannot be null`
2. **T6 参数形态**：`state` 必须是数组（`['failed']`），传空串/字符串报 `4010105 数据的格式不正确`；`stepRunIds` 是逗号连接的字符串不是数组；分页参数名是 `pageNumber/pageSize` 不是 `page`
3. T6 返回失败用例为空（测试环境未拉起/用例未执行）→ 回退整 job 全量日志导出；**先在全量日志中找 job 内部真实报错**（执行器启动失败、环境排队、命令报错等），确实无有效错误才保留 DEV-CODECI-35002 封装码原文并定性平台/基础设施（置信度低，报告不引用外部平台名）
4. `DEV-CODECI-35002` 是封装码：只定位层不定位因，报告里不允许作为最终根因；实测表明大部分 35002 背后的真实报错（执行器缺参数、资源排队超时）**在全量日志导出中可见**；buildflow 任务的整 job 日志只有 build_flow 调度层记录（Follow jobs are failed 等），子任务真实编译报错必须走第 5b 步下钻
5. **flow 的 `builds[].id` 不能当 B1 的 `jobId`**：它是子任务构建实例 UUID，只适用于 obs-product 接口；传给 `build-log/export` 报 500「构建任务不属于该流水线运行实例」——必须用 T4 失败步骤 `inputs[].key='jobId'` 的构建 jobId（step3 已提取为 buildJobId/jobIdParam）
6. `build/log` 缺 `buildNo` 报 `4010102`；`buildNo` 取 flow `builds[].build_no`（接口内不回显），不是运行号 rn
7. 用例日志 HTML 报错提取：行正则必须允许 `<tr class="...">`（`<tr[^>]*>`）；超大日志（>4MB）只扫尾部即可命中 `Test FAILED:`/`Traceback:` 摘要块；纯数字 msg 行为噪音应过滤
8. github 平台流水线（vllm-ascend 等）：openlibing-cicd 的 T4/T5/T6/E/F/B1 接口均无该平台任务/日志数据，必须走第 5c 步 GitHub Actions API；**取消 job 日志 GitHub 侧可能未留存**（per-job blob 404 BlobNotFound），此时以 jobs 元数据（conclusion/时长/失败步骤）定性并标注证据不完整；GitHub 长 matrix job 名在 ~95 字符处 `...` 截断，zip 条目名与 API job 名匹配需经净化规则（`/`→`_`、去引号/换行/制表符）；Azure blob 慢速（per-job 域实测 ~7KB/s）必须分块读 + 单块超时，整包 zip 域 ~110KB/s，目标 job >5 个时 zip 反而更快；**github 平台流水线不计算编译成功率**（N2 `buildCount`/`buildPassCount` 不采集不展示，`runHistory` bc/bpc 置 null）；**github 测试 job 日志解析**：日志内含大量 ANSI 颜色码、时间戳前缀、`##[group]` 脚本回显块与 echo 回显行（假命中来源），解析测试结果时必须全部剥离/跳过，否则会把脚本源码行误判为失败用例
9. `versionAvail` 由服务端按工作日统计，**前端/脚本只需转百分比**；不要用日历天数或运行历史自行重算可用度
10. N1 必须传 `projectId`；产品清单优先从 T1 自动发现（记录自带 projectId），config 映射仅兜底
11. **CDP 顶层 const 会污染页面**：`Runtime.evaluate` 里声明的顶层 `const PARAMS` 会持久驻留页面全局词法环境，同页二次运行同名声明直接 `SyntaxError: Identifier 'PARAMS' has already been declared`。`cdp_exec.run_page_js` 已把生成代码包进外层 async IIFE（PARAMS 为函数局部量），自写页面脚本时必须遵守同样规则
12. 同源 fetch 是鉴权关键：脚本通过 CDP 在已登录页面上下文执行 fetch，cookie 自动携带；不要脱离浏览器直接 curl

## 九、目录结构与数据流

```
openlibing-nightly-rca/
├── SKILL.md                 本文件
├── config.json              参数入口（区间/产品/阈值/缓存开关）
├── run_pipeline.py          串联第 1~6 步（--from/--only 支持断点）
├── lib/
│   ├── cdp_run.js           CDP 驱动：注入 PARAMS 执行页面 JS
│   ├── cdp_exec.py          Python 侧公共（配置/渲染执行/JSON/点灯函数）
│   ├── cache.py             采集增量缓存（按运行 rid 索引，避免重复取数据；复用前状态校准）
│   └── download_case_logs.js 用例日志并发下载（OBS 直链）
├── tpl/                     页面 JS 模板（一接口一模板，PARAMS 由步骤注入）
│   ├── t1_nightly.js        T1 产品发现 + N1 逐产品夜间明细（双指标）
│   ├── n2_dashboard.js / t4_details.js / t5_export.js / t5_logs.js / t6_testreport.js
│   └── t7_subtask.js        F flow 子任务列表 + B1 build-log/export 导出 + B2 build/log 兜底
├── steps/                   step1~step6（一步一脚本，可独立运行；step5b 为 buildflow 子任务下钻，step5c 为 GitHub 平台运行取证）
├── agent/
│   ├── agent_task.md        第 7 步 agent 任务书（无人值守输出纪律 + 深挖流程 + 措辞规则 + 表格化报告模板）
│   └── analysis_profile.json 可变分析配置（v10：双维度 + 子任务下钻 + 措辞规则）
└── out/                     全部产物（原始响应 *_raw.json、证据 JSON、case_logs/、job_logs/（整 job 全量日志 + buildflow 子任务全量日志）、github_logs/（GitHub 运行取证：gh_<runId>/ 内 jobs.json 与 job 日志）、cache/（collection.json 采集缓存）、report/、run_pipeline.log（采集全量日志，agent 终端只看摘要）、_analysis_summary.py（第 7 步分析索引摘要：全局/--pipeline/--rn 三级下钻））

数据流：T1+N1 夜间统计（工作日口径，双指标）→ 组件双维度点灯 → versionAvail!=1 或 buildSuccess!=1 的流水线（并集，dims 标注）
       → N2 执行记录双轨道圈定（VA 失败日 + BS 豁免日补圈，rid 去重；github 流水线 bc/bpc 置 null）→ 待查失败运行（以记录内 pipelineRunId 直接下钻）→ T4 分流（BS 轨道过滤 Build*）→ test/log 两路
       → T6 失败用例+日志解析 / E 全量日志导出落盘（T5 分页兜底）→ 5b buildflow 子任务下钻（flow → build-log/export → build/log 兜底）
       → 5c GitHub 平台取证（github 运行：jobs 元数据 → per-job/zip 决策树 → 404 未留存标注 → 测试 job 测试结果解析；复用前 runStatus 快照校准，变更重取；与 openlibing 平台运行互不交叉）
       → 合并 analysis_input.json（含 subTasks 子任务证据、githubMeta、github 测试任务 testResults）+ 日志落盘
       → agent 深挖失败错误（buildflow 任务以失败子任务日志为准，github 运行以 job 日志/testResults/githubJob 步骤元数据为准）→ 表格化根因报告
```

## 十、输出

- **根因分析报告**：`out/report/openlibing根因分析_<起>至<止>[_<组件>].html`（首页单表：全量开源组件概览表（双指标百分比+细进度条 + 双列待分析流水线数）+ 顶部日期筛选工具条（全部/昨天/最近 7 天/最近 30 天 + 起止日期，前端按工作日口径重算）；双维度二级页逐流水线根因表；表格固定高度、表头吸顶；已取消跨流水线共性与结论两章；页面结构固定（用户确认版），仅随数据更新，不设流程性待办章节；profile 可改为 json 等格式）
- **中间数据**：`out/` 全量留档（原始接口响应、证据 JSON、用例日志 HTML），断点续跑与复查均有据可查；采集数据只增不删、长期归档
- **采集缓存**：`out/cache/collection.json`（采集增量，已取证运行不重抓，复用前状态校准）
- 退出码约定：`0` 成功；`42` 正常提前结束（无待分析数据）；其他 = 失败，按 `--from` 续跑
