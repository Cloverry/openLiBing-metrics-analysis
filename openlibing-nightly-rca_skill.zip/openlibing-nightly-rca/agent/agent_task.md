# 第 7 步【agent 执行】AI 根因分析任务书

> 本文件是采集完成后的分析阶段指令。执行本 skill 的 AI agent 必须以本任务书为准，
> 并读取 `agent/analysis_profile.json` 获取**可变**的分析配置（分类体系、置信度规则、报告格式等均可在该文件中调整，无需改动任何代码）。

## 输入（全部只读，禁止另行抓接口）

| 文件/目录 | 作用 |
|---|---|
| `out/analysis_input.json` | 第 1~6 步合并后的结构化证据，**范围与索引的唯一数据来源** |
| `agent/analysis_profile.json` | 分析配置（profile.version 变更时应重新通读） |
| `out/job_logs/*.log` | 整 job **全量日志**（log 任务与空测试任务已导出落盘；`*.excerpt.log` 为大日志摘录）；**buildflow 失败子任务全量日志同目录落盘**（文件名 `NN_<流水线>_<构建号>_<任务>_<子任务>.log`，索引见任务 `subTasks[].logFile`） |
| `out/github_logs/gh_<runId>/` | **github 平台运行取证日志**（第 5c 步落盘：`jobs.json` job 元数据 + 失败/取消 job 主日志 `.txt` + `sys_*.txt` 系统日志；`platform: "github"` 任务的 `logFile` 指向此处，回原文规则与 job_logs 相同） |
| `out/case_logs/*.html` | 失败用例日志（test 非空任务每用例一份，含完整 stdout） |
| `out/step1_nightly_raw.json` 等中间产物 | 仅在分析输入信息不足时按需查证 |

## 无人值守输出纪律（硬性——防「输出过长，请输入继续」中断）

夜间无人值守运行，任何一步等待人工确认都会让全流程挂死。以下纪律全文生效：

1. **禁止整读大文件**：`analysis_input.json`（常 1MB+/近 2 万行）、`out/job_logs/`、`out/case_logs/`、`out/github_logs/` 中的文件一律禁止不带 offset/limit 的整读
2. **入口必走摘要脚本**：全局结构先跑 `python out/_analysis_summary.py`（约 200~300 行紧凑索引：区间/coverage/组件概览/流水线×运行×任务/缓存命中标记）；逐流水线下钻跑 `python out/_analysis_summary.py --pipeline <名子串>`（运行多时自动截断，可用 `--rn <构建号>` 单运行下钻）
3. **深挖按行号窗口读**：凭摘要里的 `文件名:行号` 用 Read 的 offset/limit（或 `grep -n` + 行号窗口）读错误行前后 10~30 行，禁止全文回显
4. **单条命令回显 ≤100 行**：可能超长的命令（报告生成、缓存写回、日志扫描）先输出重定向到临时文件再读尾部，如 `python out/_gen_report_tpl.py > out/_gen_log.txt 2>&1` 后读该文件；PowerShell 下 Python 中文输出重定向用脚本 `--out` 参数或管道 `| Select-Object -Last 40`，不要用 `>` 直重（编码吞行）
5. **分析过程不粘贴大段日志原文**：证据进报告 EV_DATA（弹窗数据），对话回显只写结论与 file:line 引用
6. **不向用户提问等待**：区间/产品等已在采集阶段确认，分析阶段遇到数据缺口按 notes 口径与现有证据定性并标注证据不完整，不得中途暂停询问

## 分析流程

1. **获取全局索引**：跑 `python out/_analysis_summary.py`（禁止整读 `analysis_input.json`），确认区间、开源组件范围与取证完整性（看板接口侧字段沿用「产品」命名，报告中统一展示为「开源组件」）；本报告为**双维度**（版本可用度 va / 编译成功率 bs，定义与灯色见 `profile.analysis.dimensions`），概览每组件含两指标与两列待分析流水线数；**VA 日可用为双指标口径**（服务端逐运行 `isVersionAvailable`：构建成功且用例通过率 100%，`--` 视为失败；`availDays` 已按此口径算好），**BS 服务端值经逐运行复算校验**（`runHistory` 的 `bc`/`bpc` 求和，仅在与服务端值不一致时于报告标注口径异常，一致时不写任何复算叙事，见 `profile.analysis.wording_rules`；github 平台流水线 bc/bpc 恒 null——不计算不展示编译成功率，构建记录弹窗不含编译次数两列）。
2. **逐流水线**分析（`pipelines[]`，每条独立小节，按 `dims` 标注归属维度：`va` = 可用度失败日取证，`bs` = 编译成功率补圈取证）；先跑 `python out/_analysis_summary.py --pipeline <流水线名子串>` 拿该流水线完整证据索引（运行/任务/用例错误/子任务/github/testResults），运行数多被截断时用 `--rn <构建号>` 逐运行下钻：
   - 逐运行 → 逐任务 → 逐用例通读证据：
     - `type: "test"` 任务：失败用例的 `description`（断言消息）+ `errorMessages`（含 `line` 行号）+ `deepHits`；用例日志原文在 `localLog` 指向的 `out/case_logs/` 文件
     - `type: "log"` 任务：`errorLines`（`L<行号>:` 前缀错误行）；**整 job 全量日志已落盘**（`logFile` 字段，`out/job_logs/` 目录），大日志先读 `excerpt` 摘录
     - **github 平台任务**（`platform: "github"`，`type: "log"` 形态）：`errorLines` 前缀规则同上，日志原文在 `out/github_logs/gh_<runId>/`（`logFile` 指向）；运行级 `githubMeta` 提供 mode/why/failedJobs（含失败步骤名与 conclusion）/cancelledJobs/systemLogs/missing；`evidenceNote` 非空的任务为 **GitHub 侧日志未留存（404）**——按 jobs 元数据定性（`githubJob.conclusion`/时长/失败步骤 `githubJob.steps`），错误信息写实际失败情况并标注证据不完整，不得虚构日志内容；github 流水线 `buildSuccess` 恒为 null，仅 VA 维度分析（BS 二级页不列）
     - **github 测试任务结果定位**（`isTestJob: true` 的任务）：任务附 `testResults` 结构化测试结果——`failedModels`（accuracy 任务逐模型失败，含该模型最近的 pytest FAILED 与汇总行）、`aisbenchFailed`（失败用例 case + reason）、`benchmarkFailed`、`failedTagTests`（FAIL_TAG ✗）、`pytestFailed`/`pytestSummaries`（pytest 失败用例与汇总）；**测试任务的根因必须定位到具体失败用例/模型**：错误信息优先写 `testResults` 中的用例/模型名与失败原因，行号引用回 job 日志原文（`testResults` 各条目带 `line` 行号），与 `errorLines` 互相印证；`testResults` 为 null（日志 404 未留存或无失败输出）时退回 errorLines 定性
     - **buildflow 子任务证据**（`profile.deep_dive.subtask_drilldown`）：`type: "log"` 任务若 `subTasks` 非空（buildflow 任务），失败子任务（`status: "FAILURE"`）的真实编译报错以 `subTasks[].errorLines` 为准、日志原文在 `subTasks[].logFile`（`out/job_logs/` 子任务全量日志）；整 job 日志中的 build_flow 调度层记录（Follow jobs are failed 等）仅作调度上下文，不得作为最终报错；`subTasks: []` 为普通任务，直接以整 job 日志为准
   - **BS 维度任务口径**：编译成功率维度的失败仅指子任务名以 `Build`（大小写不敏感）开头的任务失败；`track: "bs"` 的运行仅分析 Build* 失败任务
   - **BS 复算校验（仅异常时标注）**：`bsCleanRuns` 列出的运行（下钻后 Build* 任务全部成功）不编根因行；用逐运行复算（Σ`runHistory.bpc` / Σ`runHistory.bc`，**null 条目跳过**；github 平台流水线 bc/bpc 恒 null 不参与复算、不展示编译次数）与服务端 `buildSuccess` 比对——一致时不写任何比对叙事，按真实构建失败（来自其他运行）定性；**不一致（差异超过 0.5 个百分点）时才标注统计口径异常**（如挂起运行按评估日重复计数），标注位置为该流水线小节（BS 二级页）标题旁的小字 note
   - **用例通过率未达 100% 的不达标**：按 `profile.analysis.wording_rules` 表格化——作为根因表一条记录（九列齐全），错误信息写实际问题（如哪几天通过率为空/具体失败用例与断言），原因与建议写清楚，不写复算类描述
   - **深挖（本步核心）**：对每条疑似根因，凭 `errorLines` 的行号 / `errorMessages[].line` / `stepErrMsgs` 回对应日志文件定位错误上下文：
     - 用 `grep -n` / `sed -n '<起>,<止>p'` 读取全量日志中错误行前后 10~30 行（github 平台任务回 `out/github_logs/` 对应 job 日志，规则相同）
     - 找到**真实报错原文**（具体编译错误、具体命令输出、具体异常堆栈、具体资源错误），把根因从「封装码/断言消息」下钻到「具体哪一步、什么报错、为什么」
     - `truncated: true`（分页兜底）的日志只有局部内容，结论需注明证据不完整；github 任务 `evidenceNote` 非空（404 未留存）时以 jobs 元数据定性并注明证据不完整
   - **排队类根因（Pending/queued 资源等待）必须举证完整等待时间线**（`profile.deep_dive.pending_timeline`）：申请开始时间 → 首查状态（status/progress）→ 轮询总次数与每轮间隔 → 放弃/分配失败时间，四个节点逐点括注 `文件名:行号`；等待时长=起止时间差（如 约 1h44m），**不得用轮询次数×固定间隔推算**（各流水线每轮「查询耗时+等待」不同）；调度器返回的结构化原因须摘录关键细节（reason code 如 INSUFFICIENT_NPU、requested/observed 资源明细、lease 预留占用）；禁止只写「资源调度失败/排队超时」等无时长、无日志行举证的笼统结论；证据弹窗（EV_DATA records）同步补齐全部时间线节点记录
   - 每条证据按 profile 的 `classification` 定性 + `confidence_rules` 定置信度
   - 同一流水线内先按任务/用例归并，再按「同一根因」聚类编号（如 MS-MSLIM-01），统计复现次数与首末日
   - 记录每条根因关联的运行 `rn` 与 `openlibingUrl`（用于报告构建定位链接）
3. **跨流水线共性检查（仅作分析参考，不写入报告）**：按 profile 的 `context_dimensions` 检查（同任务名跨流水线复现、同日期批量失败、环境镜像类缺陷共性等），结论用于帮助判定单条根因的定性与建议方向；**首页已取消「跨流水线共性」章节，共性内容不再单独成表、不编 C-/CB- 编号**。
4. **建议方向（落在根因行内）**：每条根因的「建议」列按 profile.report 的优先级体系（默认 P0/P1/P2）给出可执行方向；**首页已取消「结论与建议」章节，行动项不再单独成表**，P0/P1/P2 优先级与建议方向就在根因行内落地。

**证据引用格式（硬性）**：深挖引用一律写 `文件名:行号`（如 `01_msot_242_Test_msot_nightly_smoke_A3.log:L58213`、`case_xxx.html:412`），行号必须来自全量日志（摘录文件行号不连续，引用前必须回全量文件核对）。

## 报告模板（单组件与多组件共用同一模板，HTML 形式）

按 `profile.report` 生成**单个自包含 HTML 文件**（内嵌 CSS/少量原生 JS，无外部依赖，双击浏览器可直接打开）。
**页面宽度 `width:min(1560px,94vw); margin:0 auto` 居中展示**（大屏铺满、超宽屏不定宽拉伸）。
报告采用**总览页 + 二级页**两级视图（JS 显隐切换，仍单文件）：逐流水线根因放在二级页，
总览页只有一张「开源组件级概览」表 + 顶部日期筛选工具条（不设共性/结论/流程性待办章节）。骨架：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="utf-8"><title>openLiBing Nightly 根因分析（{start} ~ {end}）</title>
<style>/* 内嵌：系统字体栈 / 表格斑马纹 / 指标百分比+6px 进度条 .rate-line .bar.green|.yellow|.red|.gray / 日期工具条 .toolbar .seg / 固定高度表容器 .tbl-wrap + sticky 表头 / 弹窗 .modal / 蓝色链接 / 面包屑 .crumb / 证据角标 .evtag */</style></head>
<body>
  <div class="wrap"><!-- width:min(1560px,94vw); margin:0 auto -->
  <!-- ===== 总览视图 #view-home ===== -->
  <div id="view-home">
  <h1>openLiBing Nightly 根因分析（{start} ~ {end}）</h1>
  <p class="meta">仅写：分析对象、证据采集时间与规模；禁止写统计口径、接口字段、工作日规则等说明性长文</p>

  <div class="toolbar">
    <span class="lbl">统计区间</span>
    <span class="seg" id="seg">
      <button data-range="all" class="on">全部</button>
      <button data-range="prev">昨天</button>
      <button data-range="7">最近 7 天</button>
      <button data-range="30">最近 30 天</button>
    </span>
    <input type="date" id="d-from"><span class="tilde">~</span><input type="date" id="d-to">
    <span class="hint" id="range-hint">2026-10-26 ~ 2026-11-03｜7 个工作日</span>
  </div>

  <h2>开源组件级概览</h2>
  <div class="tbl-wrap"><!-- 高度固定 calc(100vh - 330px) 且 min-height:440px；thead sticky；行数增减不改变表格高度，超出内部滚动 -->
  <table class="ov" id="ov-table">
    <thead>开源组件 | 版本可用度（百分比 + 6px 进度条）| 编译成功率（百分比 + 6px 进度条）| 口径内流水线数 | 待分析流水线数（版本可用度）（data-view=组件ID-va）| 待分析流水线数（编译成功率）（data-view=组件ID-bs）</thead>
    <tbody><!-- 全量开源组件一律列出（待分析数为 0 也显示 0、不可点击）；该维度整体无数据填 — 并灰化该行 -->
  </table>
  </div>
  <p class="tnote">口径说明：VA/BS 公式、工作日口径、未取证流水线占位补足、非全区间按逐日矩阵前端重算</p>

  <footer>生成时间 / 分析区间 / coverage 统计</footer>
  </div>

  <!-- ===== 二级视图：每组件两个 .subview（维度分页） ===== -->
  <div class="subview" id="view-{组件ID}-va" style="display:none">
    <div class="crumb"><span class="lnk" data-back="1">‹ 返回总览</span>｜<b>{组件名}</b>（版本可用度维度，N 条待分析流水线：…）</div>
    <!-- 每条流水线一个 <section>（仅 versionAvail != 1 的流水线）：标题含可用度徽章 + 「查看构建记录」链接（data-modal）；
         根因表列: 根因编号 | 任务 | 用例 | 错误信息 | 定性 | 置信度 | 执行记录 | 构建定位 | 建议 -->
  </div>
  <div class="subview" id="view-{组件ID}-bs" style="display:none">
    <div class="crumb"><span class="lnk" data-back="1">‹ 返回总览</span>｜<b>{组件名}</b>（编译成功率维度，N 条待分析流水线：…）</div>
    <!-- 每条流水线一个 <section>（仅 buildSuccess != 1 的流水线）：标题含编译成功率徽章（逐运行复算仅在与服务端值不一致时附口径异常小字）+「查看构建记录」链接（data-modal）；
         根因表仅列 Build* 任务失败类根因；bsCleanRuns 流水线不编根因行，note 仅在服务端值与复算不一致时标注口径异常；
         无根因小节的组件（403 无权限等）也要有二级页，说明不可取证原因；github 平台流水线已由第 5c 步正常取证（根因行任务列展示 github job 名），
         仅 BS 维度无数据（buildSuccess 恒 null → BS 待分析数为 0 不可点击） -->
  </div>

  <!-- ===== 弹窗：构建记录 modal（每流水线一个） + 动态证据/执行记录 modal ===== -->
  </div>
  <script>/* EV_DATA 内嵌证据与执行记录数据；addEventListener 事件委托，按 data-* 分发：view/back/modal/ev/exec/close */</script>
</body></html>
```

**HTML 硬性规范**：

1. 页面容器 `width:min(1560px,94vw); margin:0 auto`，居中；其余区域留白
2. **术语统一**：全文（表头、章节标题、meta、footer、待办）使用「开源组件」，不得出现「产品」字样
3. `错误信息` 列必须来自证据原文（用例 `errorMessages[].msg` / 任务 `errorLines` / `description`），默认截断至 `profile.report.table.max_error_chars`（默认 120）字符；HTML 中换行用 `<br>`，纯文本对照时用 `⏎`，禁止单元格内出现真实换行破坏结构
4. **错误信息列可点击**：整格可点击（`data-ev=根因编号`，hover 高亮），末尾加「N 条证据」蓝字角标；点击弹窗按 时间 | 来源文件 | 报错记录原文 列出该根因的全部证据（原文不截断，来源文件含目录前缀如 `case_logs/case_0001.html:L531`）；无证据的行（403 等）不设点击与角标；证据数据以 JS 常量内嵌（`records: [{time, source, text}]`）
5. 根因编号规则：`<组件缩写>-<流水线缩写>-<序号>`，如 `MS-MSLIM-01`（首页已取消共性/结论章节，不再使用 C-/CB- 编号）
6. 一条根因一行；同一根因多处复现时合并为一行，不得同一错误重复占多行
7. 空值填 `—`，不得留空单元格
8. **构建定位列**必须为蓝色可点击链接（`<a target="_blank">`），链接来自 `runs[].openlibingUrl`（openlibing 域名 `/apps/pipelineDetail?pipelineId=&projectId=&pipelineRunId=`），链接文本为 `#构建号`，多个运行去重后空格分隔；无链接时填 `—`
9. **构建记录弹窗**：每条流水线标题旁放「查看构建记录」蓝色链接（`data-modal`）；弹窗内表格 7 列：构建号（`<a href='runHistory.url' target='_blank'>#rn</a>` 可点击跳转，与构建定位同链，缺失时纯文本）| 开始时间 | 结束时间 | 编译次数（`bc`，缺失展示 --）| 编译成功次数（`bpc`，缺失展示 --）| 失败任务类型（`ftt`，流水线未失败展示 --，其余原文输出）| 构建状态，数据取 `pipelines[].runHistory`（已按开始时间降序，直接渲染），状态用与正文一致的状态徽章着色；**github 平台流水线不计算编译成功率（bc/bpc 恒 null）——弹窗去掉「编译次数/编译成功次数」两列（渲染 5 列）**；禁止把逐日状态平铺在正文
10. **执行记录列**（原「复现」列改名）：主链接「N 条执行记录」（`data-exec=根因编号`）点击弹窗展示 任务名 | 构建号 | 执行时间（任务级开始时间，按开始时间降序），弹窗标题括注复现摘要；链接下方小字保留复现摘要 `N 任务 × M 运行 | 日期（工作日/周末）`（跨多天写首末日）；执行数据以 JS 常量内嵌（`exec: [{jobName, rn, start}]`）；无执行记录填 `—`
11. **二级页跳转（按维度分页）**：概览表「待分析流水线数（版本可用度）/（编译成功率）」两列分别为蓝色链接（`data-view=组件ID-va` / `data-view=组件ID-bs`），点击 JS 显隐切换到该组件对应维度二级页（面包屑「‹ 返回总览」`data-back` 返回）；每组件两个二级页：VA 页列 `versionAvail != 1` 的流水线，BS 页列 `buildSuccess != 1` 的流水线；同一流水线两维都命中则两个页都出现，根因行共用同一编号与证据数据（不重复编号）；某维度待分析数为 0 时填 0 不可点击；逐流水线根因内容全部放在二级页，总览页不得出现根因小节
12. **首页日期筛选（前端重算，不重新抓数）**：概览表上方工具条含 4 个快捷按钮（`data-range=all|prev|7|30`，分别对应「全部 / 昨天 / 最近 7 天 / 最近 30 天」）+ 两个 `<input type="date">`（起止日，可随机选日）；区间下限按数据可用范围自动 clamp（如选 30 天但数据只有 9 天，则从最早有数据的工作日起算）；切换区间时按每组件逐日矩阵重算 VA/BS 并原地回写百分比与进度条，口径：`VA = (Σ区间内可用日 + 未取证流水线数×区间工作日数) / ((已取证流水线数+未取证流水线数)×区间工作日数)`、`BS = (Σ区间内 buildPassCount + 占位补足项) / (Σ区间内 buildCount + 占位补足项)`，占位补足项 = 每组件反解出的增量 × 区间工作日数 / 全区间工作日数；**统计只计工作日（周一至周五）**，周末与区间外数据一律过滤；某区间内某组件无任何数据则显示 `—` 并灰化该行
13. **BS 复算校验（仅异常时标注）**：逐运行复算（Σ`runHistory.bpc` / Σ`runHistory.bc`，Σbc=0 时不复算）仅在与服务端 `buildSuccess` 差异超过 0.5 个百分点时，才在流水线小节标题（编译成功率徽章后）展示小号灰字「逐运行复算 Σ编译成功/Σ编译次数 = x/y = z%，与服务端值不一致」；一致时不展示任何复算说明；`bsCleanRuns` 涉及的流水线不编根因行，BS 二级页对应小节 note 仅在不一致时标注口径异常
14. 指标呈现：开源组件概览「版本可用度」「编译成功率」两列渲染为「百分比文本 + 6px 细进度条」（`.rate-line` 内 `.pct` 文本 + `.bar` 进度条，宽度即百分比，不单设灯色列）；VA 灯色 `>=90%` 绿 / `[80%,90%)` 黄 / `<80%` 红，BS 灯色 `=100%` 绿 / `[95%,100%)` 黄 / `<95%` 红；流水线小节标题旁徽章同规则（VA 页用可用度、BS 页用编译成功率）
15. 单文件自包含：禁止外链 CSS/JS/图片；JS 仅限视图切换与弹窗开合（`addEventListener` 事件委托，按 `data-*` 属性分发），禁止内联 `onclick` 属性；弹窗支持按钮/遮罩/ESC 三种关闭方式；中文编码 utf-8

## 硬性规则（不随 profile 变化）

1. **封装错误码不算结论**：`DEV-CODECI-35002` 等封装码只定位「失败发生在云构建层」，根因必须落到任务日志/用例日志/**buildflow 子任务日志**中的具体报错；profile.wrapper_codes 有完整清单。**深挖顺序**：先在已落盘的整 job 全量日志（`out/job_logs/`）中找任务内部的真实报错（调度失败、环境拉起、资源不足等在 job 日志内可见的原文）；buildflow 任务（`subTasks` 非空）再下钻失败子任务日志（整 job 日志只有 build_flow 调度层记录，子任务真实编译报错不在其中）；github 平台任务（`platform: "github"`）回 `out/github_logs/` 的 job 日志按同一规则定位；全量日志与子任务日志中确实无有效错误的，才定性填「平台/基础设施」、置信度填「低」、错误信息保留封装码原文并注明「日志无有效报错，真实根因待核对」
2. **报告措辞规则（profile.analysis.wording_rules，全文硬性生效）**：
   - 全文**不出现「需到 XX 平台查看」类跨平台说辞与禁止清单内品牌名**（devcloud 等，清单见 `profile.analysis.wording_rules`）：全部证据已由采集脚本落盘本地（openLiBing 接口证据 + buildflow 子任务下钻日志 + github 平台运行经第 5c 步取证的 `out/github_logs/` 日志），报告只引用本地落盘证据（`文件名:行号`），不引导读者去任何外部平台查看；github 运行在报告中的运行标识以流水线名 + 构建号呈现
   - **不写「与…一致 / 计算一致 / 复算一致」类描述**：服务端统计值与逐运行复算仅在两者不一致（异常）时标注口径问题；一致时直接按真实失败定性，不展示复算过程
   - **测试用例通过率未达 100% 导致的不达标**作为根因表一条记录（九列齐全），写清问题与原因，不写复算类描述
   - 报告只呈现结论与异常，不复述指标计算过程
3. **每行根因必须带证据引用**：开源组件 / 流水线 / 任务（test 任务精确到用例）/ 错误消息原文 / 构建定位链接 / **深挖引用（`文件名:行号`，来自全量日志或子任务全量日志）**
4. **不得虚构**：日志没写的不要推断为事实；只能以「指向/待核对」表述假设
5. **notes 仅作分析参考**：`analysis_input.notes` 中的流程性说明（工作日口径、CANCELED 规则、github 取证口径与 404 未留存等）仅供 agent 理解数据口径与取证范围，**不写入报告**（报告不设流程性待办章节）
6. 指标数值一律用 `analysis_input` 中接口返回值（组件级为 `ops-overview/main` 的 `nightlyVersionAvailabilityRate` / `nightlyBuildSuccessRate`，流水线级为 `versionAvailabilityRate` / `buildSuccessRate`，均服务端工作日口径，转百分比保留两位）；**唯一例外**是首页日期筛选切换到非全区间时，由前端按内嵌逐日矩阵与服务端口径同构重算（全区间渲染值必须与服务端接口值一致），不得用日历天数替代工作日
7. 报告语言、文件名、输出目录、章节与列清单严格按 profile.report 执行
8. **报告自包含，只呈现本次最新结论**：禁止与既往报告/上期结论做对比叙事（「此前被遮蔽」「上周报告」「与上期结论相比」「本次挖出」等表述一律不得出现）；问题持续存在时用「存量缺陷，未闭环」等当前事实表述
9. **排队类根因时间线举证**：Pending/queued 等资源等待类根因，错误信息与证据弹窗必须给出「申请开始 → 首查状态 → 轮询次数与间隔 → 放弃/失败」四个时间节点，逐点引用 `文件名:行号`（来自全量日志）；等待时长按起止时间差表述，不得以轮询次数×固定间隔推算（各流水线每轮间隔不同）；调度器结构化原因（reason code / requested / observed / lease 预留）须摘录原文；禁止只写「资源调度失败」类无时长、无举证的笼统结论
10. **页面结构固定（用户确认版）**：报告页面结构以当前版本为准——首页 = 一张「开源组件级概览」全组件表（含待分析为 0 的组件）+ 顶部日期筛选工具条（全部/昨天/最近 7 天/最近 30 天 + 起止日期组件）+ 表下口径说明 + footer；表容器固定高度、表头吸顶，行数增减不改变表格高度；**已取消「跨流水线共性」「结论与建议」两章**；二级页层级（组件×维度）+ 9 列根因表 + 构建记录/证据/执行记录三类弹窗保持不变。后续分析仅替换数据内容，**不得自创新结构、增删章节、改动视图层级或重排版式**；确需结构变更必须先向用户提出、经确认后实施
11. **一次生成定稿，禁止循环生成**：同一区间报告生成并校验通过后即定稿，不得反复重排结构、生成多版或并行维护第二套生成器；因措辞/数据修正需要重渲染时，用同一生成器重跑并覆盖同一文件名（不新增文件、不换命名、不重构模板），修正点直接落在生成器源码与数据文件中

## 输出

- 报告文件：按 `profile.report.filename_template` 生成（默认 `openlibing根因分析_{start}至{end}[_{product}].html`），写入 `profile.report.output_dir`（默认 `out/report/`）。单产品时 `{product}` 占位符替换为产品名，多产品或全部产品时该段省略
- 若 `profile.report.formats` 含 `json`，同时输出结构化版本（meta / productsOverview / rca[] / commonalities[] / conclusion[] 四段，rca 每条含 id、pipeline、task、case、evidence、classification、confidence、recurrence、runLinks、suggestion）

## 可变性说明（给 skill 使用者）

- 调整**分析维度/分类**：改 `analysis_profile.json` 的 `analysis.classification`（可增删类别）
- 调整**置信度标准**：改 `analysis.confidence_rules`
- 调整**报告措辞**：改 `analysis.wording_rules`（跨平台说辞禁令、复算仅异常标注、用例通过率不达标表格化等）
- 调整**指标口径与灯色**：改 `analysis.dimensions`（va/bs 两维度的定义、数据来源、灯色阈值）
- 调整**buildflow 子任务下钻规则**：改 `analysis.deep_dive.subtask_drilldown`
- 调整**github 平台取证展示**：改 `analysis.deep_dive.github_evidence`（404 未留存的定性口径、取消 job 处理、任务列 job 名展示）
- 追加**专项关注点**：往 `analysis.extra_focus` 加字符串，agent 会作为附加分析项执行
- 改**报告内容项**：改 `report` 节（语言、文件名模板、输出目录、章节与列定义、表格截断长度、html 样式提示、是否输出 json）。**注意：页面结构（章节构成、总览+二级页视图层级、三类弹窗）为固定项不在可变范围**，改结构须先经用户确认（见硬性规则 11/12）
- 采集与分析完全解耦：改 profile 不影响 out/ 下任何数据，可对同一份证据反复重分析；分析配置只影响 agent 的取证范围与报告口径，不改动已归档的采集数据
